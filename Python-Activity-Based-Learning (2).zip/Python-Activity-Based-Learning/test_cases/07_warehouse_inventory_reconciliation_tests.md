# Test Cases — Warehouse Inventory Reconciliation

| Test input / scenario | Expected result |
|---|---|
| Pen;100;20;30;90;120 | Expected 90; recorded 90; MATCH; replenishment 30 |
| Book;50;10;15;40;60 | Expected 45; recorded 40; difference -5; DISCREPANCY; replenishment 20 |
| Box;5;0;8;0;2 | Input error: Dispatched quantity cannot exceed available stock. |

