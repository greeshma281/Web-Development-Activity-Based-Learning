# Test Cases — Employee Payroll and Deduction Analysis

| Test input / scenario | Expected result |
|---|---|
| Ravi;20000;4;1000 | Gross ₹28,200.00; deduction ₹564.00; net ₹27,636.00 |
| Maya;25000;10;2000 | Gross ₹34,000.00; deduction ₹1,700.00; net ₹32,300.00 |
| Ravi;-1;0;0 | Input error: Salary inputs cannot be negative. |

