# Test Cases — Advanced Numeric Pattern Generator

| Test input / scenario | Expected result |
|---|---|
| 3 |  1 / 121 / 1 (symmetric diamond) |
| 5 |   1 /  121 / 12321 /  121 /   1 |
| 4 | Input error: Height must be an odd integer from 3 to 19. |

