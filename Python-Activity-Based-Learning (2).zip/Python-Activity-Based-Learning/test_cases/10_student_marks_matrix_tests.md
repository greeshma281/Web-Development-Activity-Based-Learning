# Test Cases — Student Marks Matrix Analysis

| Test input / scenario | Expected result |
|---|---|
| provided sample matrix | Asha total 253 average 84.33; Ravi total 225 average 75.00; Neha total 148 average 49.33; top performer Asha; no subject average below 50 for this sample |
| mark = 101 | Error: marks must be between 0 and 100 |
| row missing a subject | Error: every student must have marks for each subject |

