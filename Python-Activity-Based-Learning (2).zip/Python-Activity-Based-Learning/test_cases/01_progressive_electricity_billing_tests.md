# Test Cases — Progressive Electricity Billing

| Test input / scenario | Expected result |
|---|---|
| 50 | Energy ₹75.00; rebate ₹3.75; fixed ₹50.00; total ₹121.25 |
| 150 | Energy ₹275.00; rebate ₹0.00; fixed ₹50.00; total ₹325.00 |
| 250 | Energy ₹550.00; rebate ₹0.00; fixed ₹50.00; total ₹600.00 |
| -5 | Input error: Units consumed cannot be negative. |

