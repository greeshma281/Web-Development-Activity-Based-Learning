# Test Cases — Retail Billing with Multiple Discount Rules

| Test input / scenario | Expected result |
|---|---|
| 1;Notebook;100;2;other | Subtotal ₹200.00; discount ₹0.00; tax ₹10.00; total ₹210.00 |
| 2;Headphones;1500;1;electronics;Mouse;600;1;other | Subtotal ₹2,100.00; discount ₹210.00; tax approximately ₹252.90; total approximately ₹2,142.90 |
| 0 | Input error: Enter at least one product. |

