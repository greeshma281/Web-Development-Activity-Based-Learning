# Test Cases — Text Compression Using Character Runs

| Test input / scenario | Expected result |
|---|---|
| AAABBCCCC | Encoded A3B2C4; encoded size 6 vs original size 9; compression beneficial |
| ABC | Encoded A1B1C1; original kept because encoding is longer |
| empty input | Encoded text is empty; original text is kept |

