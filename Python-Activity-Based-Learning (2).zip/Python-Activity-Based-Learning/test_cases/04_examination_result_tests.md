# Test Cases — Examination Result and Grace-Mark Validation

| Test input / scenario | Expected result |
|---|---|
| 80,75,38,65,70 | Python becomes 40 with 2 grace marks; all subjects pass |
| 80,75,30,65,70 | Fail; no grace applied |
| 100,100,100,100,100 | Average 100.00; Distinction |

