# Test Cases — Attendance Recovery Computation

| Test input / scenario | Expected result |
|---|---|
| 40;30 | Current attendance 75.00%; required future classes 0 |
| 40;20 | Current attendance 50.00%; required future classes 40 |
| 10;12 | Input error: Attended classes must be between 0 and classes held. |

