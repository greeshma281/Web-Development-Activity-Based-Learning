# Test Cases — ATM Transaction Sequence Simulation

| Test input / scenario | Expected result |
|---|---|
| 3;deposit 1000;withdraw 500;withdraw 3000 | Final balance ₹5,500.00; accepted 2; rejected 1 |
| 2;withdraw 6000;deposit 100 | Final balance ₹5,100.00; accepted 1; rejected 1 |
| 1;deposit -10 | Rejected: amount must be positive. |

