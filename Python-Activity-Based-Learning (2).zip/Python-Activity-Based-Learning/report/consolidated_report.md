# Consolidated Python ABL Report

**Student name:** ____________________  
**Roll number:** ____________________  
**Branch/Section:** ____________________

## 01. Progressive Electricity Billing

**Problem statement:** Calculate an electricity bill using progressive consumption slabs, a fixed charge, and a rebate for low consumption. Validate that the units entered are not negative.


**Objectives:** Apply conditional statements to progressive tariff slabs.; Use variables, arithmetic operators, and input validation.; Display a clear itemized bill.


**Assumptions:** First 100 units cost ₹1.50 per unit.; Next 100 units (101–200) cost ₹2.50 per unit.; Units above 200 cost ₹4.00 per unit.; A fixed charge of ₹50 is added.; A 5% rebate on the energy charge is applied when consumption is 100 units or less.


**Algorithm:** Start. Read units consumed. If units are negative, display an error and stop. Calculate the energy charge slab by slab. Apply the fixed charge and eligible rebate. Display energy charge, rebate, fixed charge, and total bill. Stop.


**Pseudocode:**
```text
START
INPUT units
IF units < 0: PRINT invalid input; STOP
IF units <= 100: energy = units * 1.50
ELSE IF units <= 200: energy = 100*1.50 + (units-100)*2.50
ELSE: energy = 100*1.50 + 100*2.50 + (units-200)*4.00
IF units <= 100: rebate = energy * 0.05 ELSE rebate = 0
total = energy - rebate + 50
PRINT itemized bill
END
```


**Source file:** `programs/01_progressive_electricity_billing.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| 50 | Energy ₹75.00; rebate ₹3.75; fixed ₹50.00; total ₹121.25 |
| 150 | Energy ₹275.00; rebate ₹0.00; fixed ₹50.00; total ₹325.00 |
| 250 | Energy ₹550.00; rebate ₹0.00; fixed ₹50.00; total ₹600.00 |
| -5 | Input error: Units consumed cannot be negative. |


**Conclusion:** The program calculates a progressive electricity bill, applies a conditional rebate, and rejects negative consumption.

---

## 02. Employee Payroll and Deduction Analysis

**Problem statement:** Calculate an employee's gross salary from basic pay, allowances, overtime, and incentives. Apply a simple deduction rule and print a salary statement.


**Objectives:** Calculate gross pay using arithmetic operators.; Use conditional logic for deductions.; Format a readable salary statement.


**Assumptions:** House rent allowance is 20% of basic pay.; Other allowance is 10% of basic pay.; Overtime is paid at ₹150 per hour.; Incentive is entered by the user.; Deduction is 5% of gross salary when gross salary is above ₹30,000; otherwise it is 2%.


**Algorithm:** Start. Read employee name, basic pay, overtime hours, and incentive. Validate that numeric inputs are not negative. Calculate allowances, overtime pay, and gross salary. Select the deduction percentage using the gross salary. Calculate net salary and display the statement. Stop.


**Pseudocode:**
```text
START
INPUT name, basic, overtime_hours, incentive
IF any numeric input < 0: PRINT error; STOP
hra = basic * 0.20
other = basic * 0.10
overtime_pay = overtime_hours * 150
gross = basic + hra + other + overtime_pay + incentive
IF gross > 30000: deduction = gross * 0.05 ELSE deduction = gross * 0.02
net = gross - deduction
PRINT salary statement
END
```


**Source file:** `programs/02_employee_payroll.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| Ravi;20000;4;1000 | Gross ₹28,200.00; deduction ₹564.00; net ₹27,636.00 |
| Maya;25000;10;2000 | Gross ₹34,000.00; deduction ₹1,700.00; net ₹32,300.00 |
| Ravi;-1;0;0 | Input error: Salary inputs cannot be negative. |


**Conclusion:** The program computes gross and net salary, applies the specified deduction rule, and validates salary inputs.

---

## 03. Retail Billing with Multiple Discount Rules

**Problem statement:** Generate an itemized retail bill for multiple products, including quantities, category-specific tax, a threshold discount, and a maximum discount limit.


**Objectives:** Store multiple items using lists and tuples.; Use loops to calculate item totals and tax.; Apply a discount rule and print an invoice.


**Assumptions:** Each product is represented by name, unit price, quantity, and tax rate.; Electronics use 18% tax; all other listed products use 5% tax.; A 10% discount is applied when the pre-discount subtotal is at least ₹2,000.; The discount cannot exceed ₹500.; Tax is calculated on the subtotal after discount.


**Algorithm:** Start. Read the number of products and each product's details. Validate price and quantity. Calculate subtotal and tax by product category. Apply the threshold discount, limited to ₹500. Calculate tax on the discounted taxable amount proportionally. Display itemized totals and final amount. Stop.


**Pseudocode:**
```text
START
INPUT number_of_items
subtotal = 0
REPEAT for each item: INPUT name, price, quantity, category; validate; line_total = price*quantity; subtotal += line_total
IF subtotal >= 2000: discount = MIN(subtotal*0.10, 500) ELSE discount = 0
discount_factor = (subtotal-discount)/subtotal if subtotal > 0 else 0
tax = SUM(line_total * tax_rate * discount_factor)
total = subtotal - discount + tax
PRINT invoice
END
```


**Source file:** `programs/03_retail_billing.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| 1;Notebook;100;2;other | Subtotal ₹200.00; discount ₹0.00; tax ₹10.00; total ₹210.00 |
| 2;Headphones;1500;1;electronics;Mouse;600;1;other | Subtotal ₹2,100.00; discount ₹210.00; tax approximately ₹252.90; total approximately ₹2,142.90 |
| 0 | Input error: Enter at least one product. |


**Conclusion:** The program uses a list of tuples to build an invoice, apply a capped discount, calculate tax, and report the final bill.

---

## 04. Examination Result and Grace-Mark Validation

**Problem statement:** Process marks across multiple subjects, apply subject-wise pass criteria and a grace-mark policy, and determine the final result without exceeding maximum marks.


**Objectives:** Use lists and loops for subject marks.; Apply pass conditions and a limited grace-mark rule.; Ensure marks do not exceed the maximum.


**Assumptions:** There are five subjects, each out of 100.; A student passes a subject with at least 40 marks.; If exactly one subject has 35–39 marks, up to 5 grace marks may be added to reach 40.; Final marks cannot exceed 100.; Classification: Distinction at average ≥75, First Class at ≥60, Second Class at ≥50, otherwise Pass; if any subject remains failed, overall result is Fail.


**Algorithm:** Start. Read marks for five subjects and validate each is between 0 and 100. Find subjects with marks below 40. If exactly one subject has 35–39, apply enough grace marks to reach 40, not exceeding the 5-mark limit. Check whether all subjects pass. Calculate average and classification if passed. Display original and final marks, grace applied, and result. Stop.


**Pseudocode:**
```text
START
INPUT marks for 5 subjects
IF any mark < 0 OR > 100: PRINT error; STOP
failed = indices where marks < 40
IF length(failed) == 1 AND 35 <= marks[failed[0]] < 40: grace = 40 - marks[failed[0]]; marks[failed[0]] += grace
IF any marks < 40: result = FAIL
ELSE calculate average and classification
PRINT marks, grace, result
END
```


**Source file:** `programs/04_examination_result.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| 80,75,38,65,70 | Python becomes 40 with 2 grace marks; all subjects pass |
| 80,75,30,65,70 | Fail; no grace applied |
| 100,100,100,100,100 | Average 100.00; Distinction |


**Conclusion:** The program checks mark ranges, applies grace marks only under the stated rule, and assigns a final classification.

---

## 05. Attendance Recovery Computation

**Problem statement:** Calculate a student's current attendance percentage and determine the minimum number of consecutive classes they must attend to reach a required eligibility percentage.


**Objectives:** Calculate percentages accurately.; Use a loop to find the minimum number of future classes required.; Validate class counts and explain the result.


**Assumptions:** Attended classes cannot exceed classes held.; Eligibility threshold is 75%.; Future classes are all attended for the recovery calculation.; If attendance already meets the threshold, required future classes are zero.


**Algorithm:** Start. Read classes held and classes attended. Validate counts. Calculate current attendance percentage. If below 75%, repeatedly add one attended class and one class held until the threshold is met. Display current percentage and required classes. Stop.


**Pseudocode:**
```text
START
INPUT held, attended
IF held < 0 OR attended < 0 OR attended > held: PRINT error; STOP
IF held == 0: PRINT no classes held; STOP
percentage = attended / held * 100
future = 0
WHILE (attended + future)/(held + future)*100 < 75: future += 1
PRINT percentage, future
END
```


**Source file:** `programs/05_attendance_recovery.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| 40;30 | Current attendance 75.00%; required future classes 0 |
| 40;20 | Current attendance 50.00%; required future classes 40 |
| 10;12 | Input error: Attended classes must be between 0 and classes held. |


**Conclusion:** The program calculates current attendance and uses a loop to find the minimum number of future classes needed to reach 75%.

---

## 06. ATM Transaction Sequence Simulation

**Problem statement:** Process a sequence of deposits and withdrawals, maintain a simulated account balance, enforce withdrawal limits, reject invalid transactions, and produce a transaction summary.


**Objectives:** Use loops and conditional statements to process transactions.; Maintain a running balance.; Reject invalid amounts and withdrawals that exceed balance or limits.


**Assumptions:** Opening balance is ₹5,000.; Each withdrawal must be positive and cannot exceed ₹2,000 or the available balance.; Deposits must be positive.; Only deposit and withdraw transaction types are accepted.


**Algorithm:** Start with opening balance. Read number of transactions. For each transaction, read type and amount. Validate amount and type. Apply valid deposit or withdrawal; reject invalid transactions without changing balance. Display each transaction result and final summary. Stop.


**Pseudocode:**
```text
START
balance = 5000; accepted = 0; rejected = 0
INPUT transaction_count
REPEAT transaction_count times: INPUT type, amount
IF amount <= 0: reject
ELSE IF type == deposit: balance += amount; accepted += 1
ELSE IF type == withdraw AND amount <= 2000 AND amount <= balance: balance -= amount; accepted += 1
ELSE reject
PRINT final balance, accepted, rejected
END
```


**Source file:** `programs/06_atm_transaction_simulation.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| 3;deposit 1000;withdraw 500;withdraw 3000 | Final balance ₹5,500.00; accepted 2; rejected 1 |
| 2;withdraw 6000;deposit 100 | Final balance ₹5,100.00; accepted 1; rejected 1 |
| 1;deposit -10 | Rejected: amount must be positive. |


**Conclusion:** The simulation safely updates the balance only for valid transactions and reports accepted and rejected operations.

---

## 07. Warehouse Inventory Reconciliation

**Problem statement:** Compare opening stock, incoming quantities, dispatched quantities, and recorded closing stock for multiple products. Detect discrepancies and calculate replenishment needs.


**Objectives:** Represent product data with lists and tuples.; Calculate expected closing stock.; Detect discrepancies and shortages against target stock.


**Assumptions:** Expected closing stock = opening stock + received − dispatched.; All quantities must be non-negative.; Target stock is supplied for each product.; A discrepancy is reported when expected stock differs from recorded stock.


**Algorithm:** Start. Read product count and each product's quantities. Validate that all quantities are non-negative. Calculate expected closing stock and compare it with recorded closing stock. Calculate replenishment needed to reach target stock. Display a reconciliation report for each product. Stop.


**Pseudocode:**
```text
START
INPUT product_count
FOR each product: INPUT name, opening, received, dispatched, recorded_closing, target
VALIDATE quantities >= 0
expected = opening + received - dispatched
difference = recorded_closing - expected
replenishment = MAX(0, target - recorded_closing)
PRINT expected, difference, replenishment, status
END
```


**Source file:** `programs/07_warehouse_inventory_reconciliation.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| Pen;100;20;30;90;120 | Expected 90; recorded 90; MATCH; replenishment 30 |
| Book;50;10;15;40;60 | Expected 45; recorded 40; difference -5; DISCREPANCY; replenishment 20 |
| Box;5;0;8;0;2 | Input error: Dispatched quantity cannot exceed available stock. |


**Conclusion:** The program reconciles stock records, flags differences, and calculates how much stock is needed to meet a target.

---

## 08. Advanced Numeric Pattern Generator

**Problem statement:** Generate a symmetric numeric diamond for a user-specified odd height, validating dimensions and aligning the output.


**Objectives:** Use nested loops to generate patterns.; Apply arithmetic and conditional logic to control spaces and numbers.; Validate user input.


**Assumptions:** Height must be an odd integer from 3 to 19.; Each row contains ascending numbers and then descending numbers.; The top and bottom rows contain only 1.


**Algorithm:** Start. Read the height. Validate that height is odd and between 3 and 19. For each row in the upper half, calculate spaces and number sequence. Repeat in reverse for the lower half. Print the symmetric diamond. Stop.


**Pseudocode:**
```text
START
INPUT height
IF height < 3 OR height > 19 OR height is even: PRINT error; STOP
middle = height // 2
FOR row from 0 to height-1:
  level = row if row <= middle else height-1-row
  PRINT (middle-level) spaces
  PRINT numbers 1 through level+1, then level down to 1
END FOR
END
```


**Source file:** `programs/08_advanced_numeric_pattern.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| 3 |  1 / 121 / 1 (symmetric diamond) |
| 5 |   1 /  121 / 12321 /  121 /   1 |
| 4 | Input error: Height must be an odd integer from 3 to 19. |


**Conclusion:** The program uses nested loops to print a symmetric numeric diamond and rejects invalid dimensions.

---

## 09. Text Compression Using Character Runs

**Problem statement:** Encode a string by grouping consecutive repeated characters and compare the encoded length with the original. Keep the original when run-length encoding is not beneficial.


**Objectives:** Process strings using loops and indexing.; Count consecutive repeated characters.; Compare lengths to decide whether compression is useful.


**Assumptions:** Encoding stores each run as character followed by its count, for example AAABB becomes A3B2.; Empty strings are supported.; If the encoded text is not shorter, the program reports that compression is not beneficial and keeps the original.


**Algorithm:** Start. Read a text string. If empty, display an empty result. Scan the string and count each consecutive character run. Build the encoded string. Compare encoded and original lengths. Display both strings and the chosen result. Stop.


**Pseudocode:**
```text
START
INPUT text
encoded = empty string
index = 0
WHILE index < length(text):
  character = text[index]; count = 1
  WHILE next character equals character: count += 1; index += 1
  APPEND character and count to encoded; index += 1
IF length(encoded) < length(text): chosen = encoded ELSE chosen = text
PRINT original, encoded, chosen
END
```


**Source file:** `programs/09_text_compression.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| AAABBCCCC | Encoded A3B2C4; encoded size 6 vs original size 9; compression beneficial |
| ABC | Encoded A1B1C1; original kept because encoding is longer |
| empty input | Encoded text is empty; original text is kept |


**Conclusion:** The program performs run-length encoding and selects the encoded representation only when it reduces string length.

---

## 10. Student Marks Matrix Analysis

**Problem statement:** Analyse marks stored in a nested list. Calculate each student's total and average, each subject's average, identify the top performer, and flag subjects with low average performance.


**Objectives:** Use nested lists to represent a marks matrix.; Calculate row-wise and column-wise statistics.; Identify top performers and low-average subjects.


**Assumptions:** Three students are recorded for three subjects: Python, Mathematics, and English.; Marks range from 0 to 100.; A subject is flagged when its class average is below 50.; If totals tie, the first student in the list is displayed as the top performer.


**Algorithm:** Start. Store student names, subject names, and marks in lists. Validate that each mark is between 0 and 100. Calculate each student's total and average. Calculate each subject's average using a nested list traversal. Find the student with the highest total. Report subjects whose average is below 50. Stop.


**Pseudocode:**
```text
START
names = [Asha, Ravi, Neha]
subjects = [Python, Mathematics, English]
marks = [[85,78,90],[65,88,72],[45,55,48]]
FOR each student row: total = SUM(row); average = total / number_of_subjects
FOR each subject column: average = SUM(column marks) / number_of_students
top_index = index of maximum student total
PRINT student statistics, subject averages, top student, low-average subjects
END
```


**Source file:** `programs/10_student_marks_matrix.py`


**Test cases:**
| Test input / scenario | Expected result |
|---|---|
| provided sample matrix | Asha total 253 average 84.33; Ravi total 225 average 75.00; Neha total 148 average 49.33; top performer Asha; no subject average below 50 for this sample |
| mark = 101 | Error: marks must be between 0 and 100 |
| row missing a subject | Error: every student must have marks for each subject |


**Conclusion:** The program demonstrates nested-list processing by calculating student and subject statistics and identifying the top performer.

---
