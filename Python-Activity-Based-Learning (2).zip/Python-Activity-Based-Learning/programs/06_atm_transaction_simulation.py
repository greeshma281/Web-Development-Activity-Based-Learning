balance = 5000.0
accepted = 0
rejected = 0

try:
    count = int(input("Enter number of transactions: "))
    if count < 0:
        raise ValueError("Transaction count cannot be negative.")

    for number in range(1, count + 1):
        kind = input(f"Transaction {number} (deposit/withdraw): ").strip().lower()
        amount = float(input("Amount (Rs.): "))
        if amount <= 0:
            print("Rejected: amount must be positive.")
            rejected += 1
        elif kind == "deposit":
            balance += amount
            accepted += 1
            print(f"Accepted. Balance: Rs. {balance:.2f}")
        elif kind == "withdraw":
            if amount > 2000:
                print("Rejected: withdrawal limit is Rs. 2000.")
                rejected += 1
            elif amount > balance:
                print("Rejected: insufficient balance.")
                rejected += 1
            else:
                balance -= amount
                accepted += 1
                print(f"Accepted. Balance: Rs. {balance:.2f}")
        else:
            print("Rejected: transaction type must be deposit or withdraw.")
            rejected += 1

    print("\n--- ATM SUMMARY ---")
    print(f"Opening balance : Rs. 5000.00")
    print(f"Final balance   : Rs. {balance:.2f}")
    print(f"Accepted        : {accepted}")
    print(f"Rejected        : {rejected}")
except ValueError as error:
    print("Input error:", error)
