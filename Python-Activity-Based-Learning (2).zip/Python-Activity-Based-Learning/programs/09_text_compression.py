text = input("Enter text to compress: ")

encoded_parts = []
index = 0
while index < len(text):
    character = text[index]
    count = 1
    while index + count < len(text) and text[index + count] == character:
        count += 1
    encoded_parts.append(character + str(count))
    index += count

encoded = "".join(encoded_parts)
if len(encoded) < len(text):
    chosen = encoded
    message = "Compression is beneficial."
else:
    chosen = text
    message = "Compression is not beneficial; original text is kept."

print("\n--- TEXT COMPRESSION ---")
print("Original text :", text)
print("Encoded text  :", encoded)
print("Original size :", len(text))
print("Encoded size  :", len(encoded))
print(message)
print("Chosen result :", chosen)
