students = ["Asha", "Ravi", "Neha"]
subjects = ["Python", "Mathematics", "English"]
marks = [
    [85, 78, 90],
    [65, 88, 72],
    [45, 55, 48]
]

if any(len(row) != len(subjects) for row in marks):
    print("Error: every student must have marks for each subject.")
elif any(mark < 0 or mark > 100 for row in marks for mark in row):
    print("Error: marks must be between 0 and 100.")
else:
    totals = [sum(row) for row in marks]
    averages = [total / len(subjects) for total in totals]
    subject_averages = []
    for column in range(len(subjects)):
        column_total = 0
        for row in marks:
            column_total += row[column]
        subject_averages.append(column_total / len(students))

    top_index = totals.index(max(totals))
    print("--- STUDENT MARKS MATRIX ANALYSIS ---")
    print(f"{'Student':10} {'Total':>7} {'Average':>9}")
    for index, name in enumerate(students):
        print(f"{name:10} {totals[index]:7} {averages[index]:9.2f}")

    print("\nSubject averages:")
    for subject, average in zip(subjects, subject_averages):
        flag = " (LOW AVERAGE)" if average < 50 else ""
        print(f"{subject:15}: {average:.2f}{flag}")

    print(f"\nTop performer: {students[top_index]} ({totals[top_index]} marks)")
