items = []
try:
    count = int(input("How many different products? "))
    if count <= 0:
        raise ValueError("Enter at least one product.")

    for index in range(count):
        print(f"\nProduct {index + 1}")
        name = input("Product name: ").strip()
        price = float(input("Unit price (Rs.): "))
        quantity = int(input("Quantity: "))
        category = input("Category (electronics/other): ").strip().lower()
        if not name or price < 0 or quantity <= 0:
            raise ValueError("Name must be given, price non-negative, and quantity positive.")
        if category not in ("electronics", "other"):
            raise ValueError("Category must be electronics or other.")
        tax_rate = 0.18 if category == "electronics" else 0.05
        items.append((name, price, quantity, tax_rate))

    subtotal = sum(price * quantity for name, price, quantity, rate in items)
    discount = min(subtotal * 0.10, 500) if subtotal >= 2000 else 0
    factor = (subtotal - discount) / subtotal if subtotal else 0
    tax = sum(price * quantity * rate * factor
              for name, price, quantity, rate in items)
    total = subtotal - discount + tax

    print("\n--- RETAIL INVOICE ---")
    print(f"{'Product':16} {'Qty':>4} {'Amount':>10}")
    for name, price, quantity, rate in items:
        print(f"{name[:16]:16} {quantity:>4} {price * quantity:>10.2f}")
    print(f"Subtotal : Rs. {subtotal:.2f}")
    print(f"Discount : Rs. {discount:.2f}")
    print(f"Tax      : Rs. {tax:.2f}")
    print(f"Total    : Rs. {total:.2f}")
except ValueError as error:
    print("Input error:", error)
