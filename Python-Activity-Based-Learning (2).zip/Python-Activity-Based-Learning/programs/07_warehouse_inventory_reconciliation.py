records = []
try:
    count = int(input("Enter number of products: "))
    if count <= 0:
        raise ValueError("Enter at least one product.")

    for index in range(count):
        print(f"\nProduct {index + 1}")
        name = input("Product name: ").strip()
        opening = int(input("Opening stock: "))
        received = int(input("Quantity received: "))
        dispatched = int(input("Quantity dispatched: "))
        closing = int(input("Recorded closing stock: "))
        target = int(input("Target stock: "))
        quantities = [opening, received, dispatched, closing, target]
        if not name or any(value < 0 for value in quantities):
            raise ValueError("Name is required and quantities must be non-negative.")
        if dispatched > opening + received:
            raise ValueError("Dispatched quantity cannot exceed available stock.")
        records.append((name, opening, received, dispatched, closing, target))

    print("\n--- INVENTORY RECONCILIATION ---")
    for name, opening, received, dispatched, closing, target in records:
        expected = opening + received - dispatched
        difference = closing - expected
        replenishment = max(0, target - closing)
        status = "MATCH" if difference == 0 else "DISCREPANCY"
        print(f"\nProduct: {name}")
        print(f"Expected closing : {expected}")
        print(f"Recorded closing : {closing}")
        print(f"Difference       : {difference}")
        print(f"Status           : {status}")
        print(f"Replenishment    : {replenishment}")
except ValueError as error:
    print("Input error:", error)
