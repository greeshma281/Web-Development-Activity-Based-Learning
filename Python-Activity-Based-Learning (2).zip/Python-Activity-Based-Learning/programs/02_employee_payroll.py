def calculate_salary(basic, overtime_hours, incentive):
    if basic < 0 or overtime_hours < 0 or incentive < 0:
        raise ValueError("Salary inputs cannot be negative.")

    hra = basic * 0.20
    other_allowance = basic * 0.10
    overtime_pay = overtime_hours * 150
    gross = basic + hra + other_allowance + overtime_pay + incentive
    deduction_rate = 0.05 if gross > 30000 else 0.02
    deduction = gross * deduction_rate
    net = gross - deduction
    return hra, other_allowance, overtime_pay, gross, deduction, net


name = input("Enter employee name: ").strip()
try:
    basic = float(input("Enter basic pay (Rs.): "))
    overtime_hours = float(input("Enter overtime hours: "))
    incentive = float(input("Enter incentive (Rs.): "))
    if not name:
        raise ValueError("Employee name cannot be empty.")
    hra, other, overtime, gross, deduction, net = calculate_salary(
        basic, overtime_hours, incentive
    )
    print("\n--- SALARY STATEMENT ---")
    print("Employee        :", name)
    print(f"Basic pay       : Rs. {basic:.2f}")
    print(f"HRA (20%)       : Rs. {hra:.2f}")
    print(f"Other allowance : Rs. {other:.2f}")
    print(f"Overtime pay    : Rs. {overtime:.2f}")
    print(f"Incentive       : Rs. {incentive:.2f}")
    print(f"Gross salary    : Rs. {gross:.2f}")
    print(f"Deduction       : Rs. {deduction:.2f}")
    print(f"Net salary      : Rs. {net:.2f}")
except ValueError as error:
    print("Input error:", error)
