def calculate_bill(units):
    if units < 0:
        raise ValueError("Units consumed cannot be negative.")

    if units <= 100:
        energy_charge = units * 1.50
    elif units <= 200:
        energy_charge = 100 * 1.50 + (units - 100) * 2.50
    else:
        energy_charge = 100 * 1.50 + 100 * 2.50 + (units - 200) * 4.00

    rebate = energy_charge * 0.05 if units <= 100 else 0
    fixed_charge = 50
    total = energy_charge - rebate + fixed_charge
    return energy_charge, rebate, fixed_charge, total


try:
    units = float(input("Enter electricity units consumed: "))
    energy, rebate, fixed, total = calculate_bill(units)
    print("\n--- ELECTRICITY BILL ---")
    print(f"Units consumed : {units:g}")
    print(f"Energy charge  : Rs. {energy:.2f}")
    print(f"Rebate         : Rs. {rebate:.2f}")
    print(f"Fixed charge   : Rs. {fixed:.2f}")
    print(f"Total bill     : Rs. {total:.2f}")
except ValueError as error:
    print("Input error:", error)
