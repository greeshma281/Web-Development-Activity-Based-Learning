try:
    held = int(input("Enter total classes held: "))
    attended = int(input("Enter classes attended: "))
    threshold = 75

    if held <= 0:
        raise ValueError("Total classes held must be greater than zero.")
    if attended < 0 or attended > held:
        raise ValueError("Attended classes must be between 0 and classes held.")

    percentage = attended / held * 100
    future = 0
    while (attended + future) / (held + future) * 100 < threshold:
        future += 1

    print("\n--- ATTENDANCE REPORT ---")
    print(f"Current attendance : {percentage:.2f}%")
    print(f"Required threshold : {threshold}%")
    if future == 0:
        print("You already meet the attendance requirement.")
    else:
        print(f"Consecutive classes to attend: {future}")
        new_percentage = (attended + future) / (held + future) * 100
        print(f"Attendance after attending them: {new_percentage:.2f}%")
except ValueError as error:
    print("Input error:", error)
