try:
    height = int(input("Enter an odd height from 3 to 19: "))
    if height < 3 or height > 19 or height % 2 == 0:
        raise ValueError("Height must be an odd integer from 3 to 19.")

    middle = height // 2
    print("\n--- NUMERIC DIAMOND ---")
    for row in range(height):
        level = row if row <= middle else height - 1 - row
        print(" " * (middle - level), end="")
        for number in range(1, level + 2):
            print(number, end="")
        for number in range(level, 0, -1):
            print(number, end="")
        print()
except ValueError as error:
    print("Input error:", error)
