PASS_MARK = 40
MAX_MARK = 100
SUBJECTS = ["English", "Mathematics", "Python", "Physics", "Communication"]

try:
    original = []
    for subject in SUBJECTS:
        mark = float(input(f"Enter marks for {subject} (0-100): "))
        if mark < 0 or mark > MAX_MARK:
            raise ValueError("Marks must be between 0 and 100.")
        original.append(mark)

    final_marks = original.copy()
    failed = [i for i, mark in enumerate(final_marks) if mark < PASS_MARK]
    grace_used = 0

    if len(failed) == 1 and 35 <= final_marks[failed[0]] < PASS_MARK:
        grace_used = PASS_MARK - final_marks[failed[0]]
        if grace_used <= 5:
            final_marks[failed[0]] = min(MAX_MARK, final_marks[failed[0]] + grace_used)

    print("\n--- EXAMINATION RESULT ---")
    for subject, before, after in zip(SUBJECTS, original, final_marks):
        print(f"{subject:16} Original: {before:5.1f}  Final: {after:5.1f}")
    print(f"Grace marks used: {grace_used}")

    if any(mark < PASS_MARK for mark in final_marks):
        classification = "Fail"
    else:
        average = sum(final_marks) / len(final_marks)
        if average >= 75:
            classification = "Distinction"
        elif average >= 60:
            classification = "First Class"
        elif average >= 50:
            classification = "Second Class"
        else:
            classification = "Pass"
        print(f"Average: {average:.2f}")

    print("Final result:", classification)
except ValueError as error:
    print("Input error:", error)
