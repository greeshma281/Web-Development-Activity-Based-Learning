# Python Activity-Based Learning (ABL) Assignment

**Course:** Python Programming  
**Repository name required by circular:** `Python-Activity-Based-Learning`

This project contains 10 selected case studies from the university-provided list. Each case study includes a problem statement, objectives, assumptions, algorithm, flowchart, pseudocode, Python source code, test cases, sample output, and conclusion.

## Selected case studies
1. Progressive Electricity Billing
2. Employee Payroll and Deduction Analysis
3. Retail Billing with Multiple Discount Rules
4. Examination Result and Grace-Mark Validation
5. Attendance Recovery Computation
6. ATM Transaction Sequence Simulation
7. Warehouse Inventory Reconciliation
8. Advanced Numeric Pattern Generator
9. Text Compression Using Character Runs
10. Student Marks Matrix Analysis

## Folder structure
- `case_studies/` — full documentation for each case study
- `programs/` — standalone Python programs
- `test_cases/` — manual test case tables
- `outputs/` — sample console output text files
- `flowcharts/` — Mermaid flowchart source files
- `report/` — consolidated report

## Run a program
Use Python 3.10 or newer. Open a terminal in the project folder and run, for example:

```bash
python programs/01_progressive_electricity_billing.py
```

All programs use core Python concepts only: variables, data types, operators, conditional statements, loops, strings, lists, nested lists, tuples, and unpacking where appropriate. No third-party packages are required.

## Before submission
1. Replace the student-detail placeholders in `report/student_details.txt` with your own name, roll number, branch, and section.
2. Run each program on your own computer and capture genuine screenshots of the console output if your faculty specifically requires screenshots. The `outputs/` folder contains reproducible sample output text, not fabricated screenshots.
3. Verify that each program and report match the exact faculty expectations.
4. Create a GitHub repository named `Python-Activity-Based-Learning`, upload the contents of this folder, and submit the repository URL to your faculty.

**Academic note:** The tariff values and policy rules in these examples are stated assumptions for educational demonstrations. They are not official utility, payroll, exam, or banking policies. Review and understand each program before submission, because the circular says the assignment must be completed independently and students should be able to explain and demonstrate their programs.
