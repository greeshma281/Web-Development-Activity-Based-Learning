# Case Study 08: Advanced Numeric Pattern Generator

## 1. Problem Statement
Generate a symmetric numeric diamond for a user-specified odd height, validating dimensions and aligning the output.

## 2. Objectives
- Use nested loops to generate patterns.
- Apply arithmetic and conditional logic to control spaces and numbers.
- Validate user input.

## 3. Assumptions
- Height must be an odd integer from 3 to 19.
- Each row contains ascending numbers and then descending numbers.
- The top and bottom rows contain only 1.

## 4. Algorithm
1. Start.
2. Read the height.
3. Validate that height is odd and between 3 and 19.
4. For each row in the upper half, calculate spaces and number sequence.
5. Repeat in reverse for the lower half.
6. Print the symmetric diamond.
7. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
INPUT height
IF height < 3 OR height > 19 OR height is even: PRINT error; STOP
middle = height // 2
FOR row from 0 to height-1:
  level = row if row <= middle else height-1-row
  PRINT (middle-level) spaces
  PRINT numbers 1 through level+1, then level down to 1
END FOR
END
```

## 7. Python Source Code
```python
try:
    height = int(input("Enter an odd height from 3 to 19: "))
    if height < 3 or height > 19 or height % 2 == 0:
        raise ValueError("Height must be an odd integer from 3 to 19.")

    middle = height // 2
    print("\n--- NUMERIC DIAMOND ---")
    for row in range(height):
        level = row if row <= middle else height - 1 - row
        print(" " * (middle - level), end="")
        for number in range(1, level + 2):
            print(number, end="")
        for number in range(level, 0, -1):
            print(number, end="")
        print()
except ValueError as error:
    print("Input error:", error)
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| 3 |  1 / 121 / 1 (symmetric diamond) |
| 5 |   1 /  121 / 12321 /  121 /   1 |
| 4 | Input error: Height must be an odd integer from 3 to 19. |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The program uses nested loops to print a symmetric numeric diamond and rejects invalid dimensions.
