# Case Study 10: Student Marks Matrix Analysis

## 1. Problem Statement
Analyse marks stored in a nested list. Calculate each student's total and average, each subject's average, identify the top performer, and flag subjects with low average performance.

## 2. Objectives
- Use nested lists to represent a marks matrix.
- Calculate row-wise and column-wise statistics.
- Identify top performers and low-average subjects.

## 3. Assumptions
- Three students are recorded for three subjects: Python, Mathematics, and English.
- Marks range from 0 to 100.
- A subject is flagged when its class average is below 50.
- If totals tie, the first student in the list is displayed as the top performer.

## 4. Algorithm
1. Start.
2. Store student names, subject names, and marks in lists.
3. Validate that each mark is between 0 and 100.
4. Calculate each student's total and average.
5. Calculate each subject's average using a nested list traversal.
6. Find the student with the highest total.
7. Report subjects whose average is below 50.
8. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
names = [Asha, Ravi, Neha]
subjects = [Python, Mathematics, English]
marks = [[85,78,90],[65,88,72],[45,55,48]]
FOR each student row: total = SUM(row); average = total / number_of_subjects
FOR each subject column: average = SUM(column marks) / number_of_students
top_index = index of maximum student total
PRINT student statistics, subject averages, top student, low-average subjects
END
```

## 7. Python Source Code
```python
students = ["Asha", "Ravi", "Neha"]
subjects = ["Python", "Mathematics", "English"]
marks = [
    [85, 78, 90],
    [65, 88, 72],
    [45, 55, 48]
]

if any(len(row) != len(subjects) for row in marks):
    print("Error: every student must have marks for each subject.")
elif any(mark < 0 or mark > 100 for row in marks for mark in row):
    print("Error: marks must be between 0 and 100.")
else:
    totals = [sum(row) for row in marks]
    averages = [total / len(subjects) for total in totals]
    subject_averages = []
    for column in range(len(subjects)):
        column_total = 0
        for row in marks:
            column_total += row[column]
        subject_averages.append(column_total / len(students))

    top_index = totals.index(max(totals))
    print("--- STUDENT MARKS MATRIX ANALYSIS ---")
    print(f"{'Student':10} {'Total':>7} {'Average':>9}")
    for index, name in enumerate(students):
        print(f"{name:10} {totals[index]:7} {averages[index]:9.2f}")

    print("\nSubject averages:")
    for subject, average in zip(subjects, subject_averages):
        flag = " (LOW AVERAGE)" if average < 50 else ""
        print(f"{subject:15}: {average:.2f}{flag}")

    print(f"\nTop performer: {students[top_index]} ({totals[top_index]} marks)")
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| provided sample matrix | Asha total 253 average 84.33; Ravi total 225 average 75.00; Neha total 148 average 49.33; top performer Asha; no subject average below 50 for this sample |
| mark = 101 | Error: marks must be between 0 and 100 |
| row missing a subject | Error: every student must have marks for each subject |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The program demonstrates nested-list processing by calculating student and subject statistics and identifying the top performer.
