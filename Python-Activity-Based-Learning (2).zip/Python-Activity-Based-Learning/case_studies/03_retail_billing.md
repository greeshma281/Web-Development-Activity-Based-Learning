# Case Study 03: Retail Billing with Multiple Discount Rules

## 1. Problem Statement
Generate an itemized retail bill for multiple products, including quantities, category-specific tax, a threshold discount, and a maximum discount limit.

## 2. Objectives
- Store multiple items using lists and tuples.
- Use loops to calculate item totals and tax.
- Apply a discount rule and print an invoice.

## 3. Assumptions
- Each product is represented by name, unit price, quantity, and tax rate.
- Electronics use 18% tax; all other listed products use 5% tax.
- A 10% discount is applied when the pre-discount subtotal is at least ₹2,000.
- The discount cannot exceed ₹500.
- Tax is calculated on the subtotal after discount.

## 4. Algorithm
1. Start.
2. Read the number of products and each product's details.
3. Validate price and quantity.
4. Calculate subtotal and tax by product category.
5. Apply the threshold discount, limited to ₹500.
6. Calculate tax on the discounted taxable amount proportionally.
7. Display itemized totals and final amount.
8. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
INPUT number_of_items
subtotal = 0
REPEAT for each item: INPUT name, price, quantity, category; validate; line_total = price*quantity; subtotal += line_total
IF subtotal >= 2000: discount = MIN(subtotal*0.10, 500) ELSE discount = 0
discount_factor = (subtotal-discount)/subtotal if subtotal > 0 else 0
tax = SUM(line_total * tax_rate * discount_factor)
total = subtotal - discount + tax
PRINT invoice
END
```

## 7. Python Source Code
```python
items = []
try:
    count = int(input("How many different products? "))
    if count <= 0:
        raise ValueError("Enter at least one product.")

    for index in range(count):
        print(f"\nProduct {index + 1}")
        name = input("Product name: ").strip()
        price = float(input("Unit price (Rs.): "))
        quantity = int(input("Quantity: "))
        category = input("Category (electronics/other): ").strip().lower()
        if not name or price < 0 or quantity <= 0:
            raise ValueError("Name must be given, price non-negative, and quantity positive.")
        if category not in ("electronics", "other"):
            raise ValueError("Category must be electronics or other.")
        tax_rate = 0.18 if category == "electronics" else 0.05
        items.append((name, price, quantity, tax_rate))

    subtotal = sum(price * quantity for name, price, quantity, rate in items)
    discount = min(subtotal * 0.10, 500) if subtotal >= 2000 else 0
    factor = (subtotal - discount) / subtotal if subtotal else 0
    tax = sum(price * quantity * rate * factor
              for name, price, quantity, rate in items)
    total = subtotal - discount + tax

    print("\n--- RETAIL INVOICE ---")
    print(f"{'Product':16} {'Qty':>4} {'Amount':>10}")
    for name, price, quantity, rate in items:
        print(f"{name[:16]:16} {quantity:>4} {price * quantity:>10.2f}")
    print(f"Subtotal : Rs. {subtotal:.2f}")
    print(f"Discount : Rs. {discount:.2f}")
    print(f"Tax      : Rs. {tax:.2f}")
    print(f"Total    : Rs. {total:.2f}")
except ValueError as error:
    print("Input error:", error)
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| 1;Notebook;100;2;other | Subtotal ₹200.00; discount ₹0.00; tax ₹10.00; total ₹210.00 |
| 2;Headphones;1500;1;electronics;Mouse;600;1;other | Subtotal ₹2,100.00; discount ₹210.00; tax approximately ₹252.90; total approximately ₹2,142.90 |
| 0 | Input error: Enter at least one product. |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The program uses a list of tuples to build an invoice, apply a capped discount, calculate tax, and report the final bill.
