# Case Study 01: Progressive Electricity Billing

## 1. Problem Statement
Calculate an electricity bill using progressive consumption slabs, a fixed charge, and a rebate for low consumption. Validate that the units entered are not negative.

## 2. Objectives
- Apply conditional statements to progressive tariff slabs.
- Use variables, arithmetic operators, and input validation.
- Display a clear itemized bill.

## 3. Assumptions
- First 100 units cost ₹1.50 per unit.
- Next 100 units (101–200) cost ₹2.50 per unit.
- Units above 200 cost ₹4.00 per unit.
- A fixed charge of ₹50 is added.
- A 5% rebate on the energy charge is applied when consumption is 100 units or less.

## 4. Algorithm
1. Start.
2. Read units consumed.
3. If units are negative, display an error and stop.
4. Calculate the energy charge slab by slab.
5. Apply the fixed charge and eligible rebate.
6. Display energy charge, rebate, fixed charge, and total bill.
7. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
INPUT units
IF units < 0: PRINT invalid input; STOP
IF units <= 100: energy = units * 1.50
ELSE IF units <= 200: energy = 100*1.50 + (units-100)*2.50
ELSE: energy = 100*1.50 + 100*2.50 + (units-200)*4.00
IF units <= 100: rebate = energy * 0.05 ELSE rebate = 0
total = energy - rebate + 50
PRINT itemized bill
END
```

## 7. Python Source Code
```python
def calculate_bill(units):
    if units < 0:
        raise ValueError("Units consumed cannot be negative.")

    if units <= 100:
        energy_charge = units * 1.50
    elif units <= 200:
        energy_charge = 100 * 1.50 + (units - 100) * 2.50
    else:
        energy_charge = 100 * 1.50 + 100 * 2.50 + (units - 200) * 4.00

    rebate = energy_charge * 0.05 if units <= 100 else 0
    fixed_charge = 50
    total = energy_charge - rebate + fixed_charge
    return energy_charge, rebate, fixed_charge, total


try:
    units = float(input("Enter electricity units consumed: "))
    energy, rebate, fixed, total = calculate_bill(units)
    print("\n--- ELECTRICITY BILL ---")
    print(f"Units consumed : {units:g}")
    print(f"Energy charge  : Rs. {energy:.2f}")
    print(f"Rebate         : Rs. {rebate:.2f}")
    print(f"Fixed charge   : Rs. {fixed:.2f}")
    print(f"Total bill     : Rs. {total:.2f}")
except ValueError as error:
    print("Input error:", error)
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| 50 | Energy ₹75.00; rebate ₹3.75; fixed ₹50.00; total ₹121.25 |
| 150 | Energy ₹275.00; rebate ₹0.00; fixed ₹50.00; total ₹325.00 |
| 250 | Energy ₹550.00; rebate ₹0.00; fixed ₹50.00; total ₹600.00 |
| -5 | Input error: Units consumed cannot be negative. |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The program calculates a progressive electricity bill, applies a conditional rebate, and rejects negative consumption.
