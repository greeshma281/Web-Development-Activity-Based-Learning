# Case Study 02: Employee Payroll and Deduction Analysis

## 1. Problem Statement
Calculate an employee's gross salary from basic pay, allowances, overtime, and incentives. Apply a simple deduction rule and print a salary statement.

## 2. Objectives
- Calculate gross pay using arithmetic operators.
- Use conditional logic for deductions.
- Format a readable salary statement.

## 3. Assumptions
- House rent allowance is 20% of basic pay.
- Other allowance is 10% of basic pay.
- Overtime is paid at ₹150 per hour.
- Incentive is entered by the user.
- Deduction is 5% of gross salary when gross salary is above ₹30,000; otherwise it is 2%.

## 4. Algorithm
1. Start.
2. Read employee name, basic pay, overtime hours, and incentive.
3. Validate that numeric inputs are not negative.
4. Calculate allowances, overtime pay, and gross salary.
5. Select the deduction percentage using the gross salary.
6. Calculate net salary and display the statement.
7. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
INPUT name, basic, overtime_hours, incentive
IF any numeric input < 0: PRINT error; STOP
hra = basic * 0.20
other = basic * 0.10
overtime_pay = overtime_hours * 150
gross = basic + hra + other + overtime_pay + incentive
IF gross > 30000: deduction = gross * 0.05 ELSE deduction = gross * 0.02
net = gross - deduction
PRINT salary statement
END
```

## 7. Python Source Code
```python
def calculate_salary(basic, overtime_hours, incentive):
    if basic < 0 or overtime_hours < 0 or incentive < 0:
        raise ValueError("Salary inputs cannot be negative.")

    hra = basic * 0.20
    other_allowance = basic * 0.10
    overtime_pay = overtime_hours * 150
    gross = basic + hra + other_allowance + overtime_pay + incentive
    deduction_rate = 0.05 if gross > 30000 else 0.02
    deduction = gross * deduction_rate
    net = gross - deduction
    return hra, other_allowance, overtime_pay, gross, deduction, net


name = input("Enter employee name: ").strip()
try:
    basic = float(input("Enter basic pay (Rs.): "))
    overtime_hours = float(input("Enter overtime hours: "))
    incentive = float(input("Enter incentive (Rs.): "))
    if not name:
        raise ValueError("Employee name cannot be empty.")
    hra, other, overtime, gross, deduction, net = calculate_salary(
        basic, overtime_hours, incentive
    )
    print("\n--- SALARY STATEMENT ---")
    print("Employee        :", name)
    print(f"Basic pay       : Rs. {basic:.2f}")
    print(f"HRA (20%)       : Rs. {hra:.2f}")
    print(f"Other allowance : Rs. {other:.2f}")
    print(f"Overtime pay    : Rs. {overtime:.2f}")
    print(f"Incentive       : Rs. {incentive:.2f}")
    print(f"Gross salary    : Rs. {gross:.2f}")
    print(f"Deduction       : Rs. {deduction:.2f}")
    print(f"Net salary      : Rs. {net:.2f}")
except ValueError as error:
    print("Input error:", error)
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| Ravi;20000;4;1000 | Gross ₹28,200.00; deduction ₹564.00; net ₹27,636.00 |
| Maya;25000;10;2000 | Gross ₹34,000.00; deduction ₹1,700.00; net ₹32,300.00 |
| Ravi;-1;0;0 | Input error: Salary inputs cannot be negative. |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The program computes gross and net salary, applies the specified deduction rule, and validates salary inputs.
