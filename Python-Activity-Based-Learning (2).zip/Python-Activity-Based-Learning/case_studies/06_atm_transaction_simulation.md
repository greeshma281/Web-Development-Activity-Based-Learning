# Case Study 06: ATM Transaction Sequence Simulation

## 1. Problem Statement
Process a sequence of deposits and withdrawals, maintain a simulated account balance, enforce withdrawal limits, reject invalid transactions, and produce a transaction summary.

## 2. Objectives
- Use loops and conditional statements to process transactions.
- Maintain a running balance.
- Reject invalid amounts and withdrawals that exceed balance or limits.

## 3. Assumptions
- Opening balance is ₹5,000.
- Each withdrawal must be positive and cannot exceed ₹2,000 or the available balance.
- Deposits must be positive.
- Only deposit and withdraw transaction types are accepted.

## 4. Algorithm
1. Start with opening balance.
2. Read number of transactions.
3. For each transaction, read type and amount.
4. Validate amount and type.
5. Apply valid deposit or withdrawal; reject invalid transactions without changing balance.
6. Display each transaction result and final summary.
7. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
balance = 5000; accepted = 0; rejected = 0
INPUT transaction_count
REPEAT transaction_count times: INPUT type, amount
IF amount <= 0: reject
ELSE IF type == deposit: balance += amount; accepted += 1
ELSE IF type == withdraw AND amount <= 2000 AND amount <= balance: balance -= amount; accepted += 1
ELSE reject
PRINT final balance, accepted, rejected
END
```

## 7. Python Source Code
```python
balance = 5000.0
accepted = 0
rejected = 0

try:
    count = int(input("Enter number of transactions: "))
    if count < 0:
        raise ValueError("Transaction count cannot be negative.")

    for number in range(1, count + 1):
        kind = input(f"Transaction {number} (deposit/withdraw): ").strip().lower()
        amount = float(input("Amount (Rs.): "))
        if amount <= 0:
            print("Rejected: amount must be positive.")
            rejected += 1
        elif kind == "deposit":
            balance += amount
            accepted += 1
            print(f"Accepted. Balance: Rs. {balance:.2f}")
        elif kind == "withdraw":
            if amount > 2000:
                print("Rejected: withdrawal limit is Rs. 2000.")
                rejected += 1
            elif amount > balance:
                print("Rejected: insufficient balance.")
                rejected += 1
            else:
                balance -= amount
                accepted += 1
                print(f"Accepted. Balance: Rs. {balance:.2f}")
        else:
            print("Rejected: transaction type must be deposit or withdraw.")
            rejected += 1

    print("\n--- ATM SUMMARY ---")
    print(f"Opening balance : Rs. 5000.00")
    print(f"Final balance   : Rs. {balance:.2f}")
    print(f"Accepted        : {accepted}")
    print(f"Rejected        : {rejected}")
except ValueError as error:
    print("Input error:", error)
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| 3;deposit 1000;withdraw 500;withdraw 3000 | Final balance ₹5,500.00; accepted 2; rejected 1 |
| 2;withdraw 6000;deposit 100 | Final balance ₹5,100.00; accepted 1; rejected 1 |
| 1;deposit -10 | Rejected: amount must be positive. |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The simulation safely updates the balance only for valid transactions and reports accepted and rejected operations.
