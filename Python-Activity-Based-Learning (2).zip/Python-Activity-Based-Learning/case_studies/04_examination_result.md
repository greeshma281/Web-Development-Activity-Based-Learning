# Case Study 04: Examination Result and Grace-Mark Validation

## 1. Problem Statement
Process marks across multiple subjects, apply subject-wise pass criteria and a grace-mark policy, and determine the final result without exceeding maximum marks.

## 2. Objectives
- Use lists and loops for subject marks.
- Apply pass conditions and a limited grace-mark rule.
- Ensure marks do not exceed the maximum.

## 3. Assumptions
- There are five subjects, each out of 100.
- A student passes a subject with at least 40 marks.
- If exactly one subject has 35–39 marks, up to 5 grace marks may be added to reach 40.
- Final marks cannot exceed 100.
- Classification: Distinction at average ≥75, First Class at ≥60, Second Class at ≥50, otherwise Pass; if any subject remains failed, overall result is Fail.

## 4. Algorithm
1. Start.
2. Read marks for five subjects and validate each is between 0 and 100.
3. Find subjects with marks below 40.
4. If exactly one subject has 35–39, apply enough grace marks to reach 40, not exceeding the 5-mark limit.
5. Check whether all subjects pass.
6. Calculate average and classification if passed.
7. Display original and final marks, grace applied, and result.
8. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
INPUT marks for 5 subjects
IF any mark < 0 OR > 100: PRINT error; STOP
failed = indices where marks < 40
IF length(failed) == 1 AND 35 <= marks[failed[0]] < 40: grace = 40 - marks[failed[0]]; marks[failed[0]] += grace
IF any marks < 40: result = FAIL
ELSE calculate average and classification
PRINT marks, grace, result
END
```

## 7. Python Source Code
```python
PASS_MARK = 40
MAX_MARK = 100
SUBJECTS = ["English", "Mathematics", "Python", "Physics", "Communication"]

try:
    original = []
    for subject in SUBJECTS:
        mark = float(input(f"Enter marks for {subject} (0-100): "))
        if mark < 0 or mark > MAX_MARK:
            raise ValueError("Marks must be between 0 and 100.")
        original.append(mark)

    final_marks = original.copy()
    failed = [i for i, mark in enumerate(final_marks) if mark < PASS_MARK]
    grace_used = 0

    if len(failed) == 1 and 35 <= final_marks[failed[0]] < PASS_MARK:
        grace_used = PASS_MARK - final_marks[failed[0]]
        if grace_used <= 5:
            final_marks[failed[0]] = min(MAX_MARK, final_marks[failed[0]] + grace_used)

    print("\n--- EXAMINATION RESULT ---")
    for subject, before, after in zip(SUBJECTS, original, final_marks):
        print(f"{subject:16} Original: {before:5.1f}  Final: {after:5.1f}")
    print(f"Grace marks used: {grace_used}")

    if any(mark < PASS_MARK for mark in final_marks):
        classification = "Fail"
    else:
        average = sum(final_marks) / len(final_marks)
        if average >= 75:
            classification = "Distinction"
        elif average >= 60:
            classification = "First Class"
        elif average >= 50:
            classification = "Second Class"
        else:
            classification = "Pass"
        print(f"Average: {average:.2f}")

    print("Final result:", classification)
except ValueError as error:
    print("Input error:", error)
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| 80,75,38,65,70 | Python becomes 40 with 2 grace marks; all subjects pass |
| 80,75,30,65,70 | Fail; no grace applied |
| 100,100,100,100,100 | Average 100.00; Distinction |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The program checks mark ranges, applies grace marks only under the stated rule, and assigns a final classification.
