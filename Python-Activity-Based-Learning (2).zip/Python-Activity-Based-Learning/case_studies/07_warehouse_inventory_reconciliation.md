# Case Study 07: Warehouse Inventory Reconciliation

## 1. Problem Statement
Compare opening stock, incoming quantities, dispatched quantities, and recorded closing stock for multiple products. Detect discrepancies and calculate replenishment needs.

## 2. Objectives
- Represent product data with lists and tuples.
- Calculate expected closing stock.
- Detect discrepancies and shortages against target stock.

## 3. Assumptions
- Expected closing stock = opening stock + received − dispatched.
- All quantities must be non-negative.
- Target stock is supplied for each product.
- A discrepancy is reported when expected stock differs from recorded stock.

## 4. Algorithm
1. Start.
2. Read product count and each product's quantities.
3. Validate that all quantities are non-negative.
4. Calculate expected closing stock and compare it with recorded closing stock.
5. Calculate replenishment needed to reach target stock.
6. Display a reconciliation report for each product.
7. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
INPUT product_count
FOR each product: INPUT name, opening, received, dispatched, recorded_closing, target
VALIDATE quantities >= 0
expected = opening + received - dispatched
difference = recorded_closing - expected
replenishment = MAX(0, target - recorded_closing)
PRINT expected, difference, replenishment, status
END
```

## 7. Python Source Code
```python
records = []
try:
    count = int(input("Enter number of products: "))
    if count <= 0:
        raise ValueError("Enter at least one product.")

    for index in range(count):
        print(f"\nProduct {index + 1}")
        name = input("Product name: ").strip()
        opening = int(input("Opening stock: "))
        received = int(input("Quantity received: "))
        dispatched = int(input("Quantity dispatched: "))
        closing = int(input("Recorded closing stock: "))
        target = int(input("Target stock: "))
        quantities = [opening, received, dispatched, closing, target]
        if not name or any(value < 0 for value in quantities):
            raise ValueError("Name is required and quantities must be non-negative.")
        if dispatched > opening + received:
            raise ValueError("Dispatched quantity cannot exceed available stock.")
        records.append((name, opening, received, dispatched, closing, target))

    print("\n--- INVENTORY RECONCILIATION ---")
    for name, opening, received, dispatched, closing, target in records:
        expected = opening + received - dispatched
        difference = closing - expected
        replenishment = max(0, target - closing)
        status = "MATCH" if difference == 0 else "DISCREPANCY"
        print(f"\nProduct: {name}")
        print(f"Expected closing : {expected}")
        print(f"Recorded closing : {closing}")
        print(f"Difference       : {difference}")
        print(f"Status           : {status}")
        print(f"Replenishment    : {replenishment}")
except ValueError as error:
    print("Input error:", error)
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| Pen;100;20;30;90;120 | Expected 90; recorded 90; MATCH; replenishment 30 |
| Book;50;10;15;40;60 | Expected 45; recorded 40; difference -5; DISCREPANCY; replenishment 20 |
| Box;5;0;8;0;2 | Input error: Dispatched quantity cannot exceed available stock. |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The program reconciles stock records, flags differences, and calculates how much stock is needed to meet a target.
