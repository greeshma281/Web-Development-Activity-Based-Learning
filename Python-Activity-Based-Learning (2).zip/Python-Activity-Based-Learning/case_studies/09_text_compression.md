# Case Study 09: Text Compression Using Character Runs

## 1. Problem Statement
Encode a string by grouping consecutive repeated characters and compare the encoded length with the original. Keep the original when run-length encoding is not beneficial.

## 2. Objectives
- Process strings using loops and indexing.
- Count consecutive repeated characters.
- Compare lengths to decide whether compression is useful.

## 3. Assumptions
- Encoding stores each run as character followed by its count, for example AAABB becomes A3B2.
- Empty strings are supported.
- If the encoded text is not shorter, the program reports that compression is not beneficial and keeps the original.

## 4. Algorithm
1. Start.
2. Read a text string.
3. If empty, display an empty result.
4. Scan the string and count each consecutive character run.
5. Build the encoded string.
6. Compare encoded and original lengths.
7. Display both strings and the chosen result.
8. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
INPUT text
encoded = empty string
index = 0
WHILE index < length(text):
  character = text[index]; count = 1
  WHILE next character equals character: count += 1; index += 1
  APPEND character and count to encoded; index += 1
IF length(encoded) < length(text): chosen = encoded ELSE chosen = text
PRINT original, encoded, chosen
END
```

## 7. Python Source Code
```python
text = input("Enter text to compress: ")

encoded_parts = []
index = 0
while index < len(text):
    character = text[index]
    count = 1
    while index + count < len(text) and text[index + count] == character:
        count += 1
    encoded_parts.append(character + str(count))
    index += count

encoded = "".join(encoded_parts)
if len(encoded) < len(text):
    chosen = encoded
    message = "Compression is beneficial."
else:
    chosen = text
    message = "Compression is not beneficial; original text is kept."

print("\n--- TEXT COMPRESSION ---")
print("Original text :", text)
print("Encoded text  :", encoded)
print("Original size :", len(text))
print("Encoded size  :", len(encoded))
print(message)
print("Chosen result :", chosen)
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| AAABBCCCC | Encoded A3B2C4; encoded size 6 vs original size 9; compression beneficial |
| ABC | Encoded A1B1C1; original kept because encoding is longer |
| empty input | Encoded text is empty; original text is kept |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The program performs run-length encoding and selects the encoded representation only when it reduces string length.
