# Case Study 05: Attendance Recovery Computation

## 1. Problem Statement
Calculate a student's current attendance percentage and determine the minimum number of consecutive classes they must attend to reach a required eligibility percentage.

## 2. Objectives
- Calculate percentages accurately.
- Use a loop to find the minimum number of future classes required.
- Validate class counts and explain the result.

## 3. Assumptions
- Attended classes cannot exceed classes held.
- Eligibility threshold is 75%.
- Future classes are all attended for the recovery calculation.
- If attendance already meets the threshold, required future classes are zero.

## 4. Algorithm
1. Start.
2. Read classes held and classes attended.
3. Validate counts.
4. Calculate current attendance percentage.
5. If below 75%, repeatedly add one attended class and one class held until the threshold is met.
6. Display current percentage and required classes.
7. Stop.

## 5. Flowchart
```mermaid
flowchart TD
    A([Start]) --> B[Read input]
    B --> C{Input valid?}
    C -- No --> D[Display error]
    D --> Z([End])
    C -- Yes --> E[Process using conditions, loops, and calculations]
    E --> F[Display result/report]
    F --> Z([End])
```

## 6. Pseudocode
```text
START
INPUT held, attended
IF held < 0 OR attended < 0 OR attended > held: PRINT error; STOP
IF held == 0: PRINT no classes held; STOP
percentage = attended / held * 100
future = 0
WHILE (attended + future)/(held + future)*100 < 75: future += 1
PRINT percentage, future
END
```

## 7. Python Source Code
```python
try:
    held = int(input("Enter total classes held: "))
    attended = int(input("Enter classes attended: "))
    threshold = 75

    if held <= 0:
        raise ValueError("Total classes held must be greater than zero.")
    if attended < 0 or attended > held:
        raise ValueError("Attended classes must be between 0 and classes held.")

    percentage = attended / held * 100
    future = 0
    while (attended + future) / (held + future) * 100 < threshold:
        future += 1

    print("\n--- ATTENDANCE REPORT ---")
    print(f"Current attendance : {percentage:.2f}%")
    print(f"Required threshold : {threshold}%")
    if future == 0:
        print("You already meet the attendance requirement.")
    else:
        print(f"Consecutive classes to attend: {future}")
        new_percentage = (attended + future) / (held + future) * 100
        print(f"Attendance after attending them: {new_percentage:.2f}%")
except ValueError as error:
    print("Input error:", error)
```

## 8. Test Cases
| Test input / scenario | Expected result |
|---|---|
| 40;30 | Current attendance 75.00%; required future classes 0 |
| 40;20 | Current attendance 50.00%; required future classes 40 |
| 10;12 | Input error: Attended classes must be between 0 and classes held. |

## 9. Sample Output
See the matching file in `outputs/`. Run the Python program with the test input to reproduce it. Sample output is illustrative; interactive prompts vary with input.

## 10. Conclusion
The program calculates current attendance and uses a loop to find the minimum number of future classes needed to reach 75%.
